import os
import re
import uuid
import shutil
import subprocess
import threading
import time
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, Form, UploadFile, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from starlette.background import BackgroundTask

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
DATA = Path(os.getenv("DATA_DIR", "/tmp/clipmatch-data"))
DATA.mkdir(parents=True, exist_ok=True)

MAX_FILE_BYTES = 100 * 1024 * 1024
MAX_REFERENCES = 5
MAX_FOOTAGE = 10
ALLOWED_VIDEO = {".mp4", ".mov", ".m4v", ".webm", ".mkv"}
ALLOWED_AUDIO = {".mp3", ".m4a", ".aac", ".wav", ".ogg"}

app = FastAPI(title="ClipMatch AI")
app.mount("/static", StaticFiles(directory=STATIC), name="static")

jobs: dict[str, dict] = {}
jobs_lock = threading.Lock()


def command(args: list[str], timeout: int = 300) -> str:
    try:
        proc = subprocess.run(
            args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, timeout=timeout, check=False
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError("Rendering took too long. Use shorter or smaller clips.")
    if proc.returncode != 0:
        error = (proc.stderr or "Media processing failed")[-1800:]
        raise RuntimeError(error)
    return proc.stdout


def duration_of(path: Path) -> float:
    out = command([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(path)
    ], timeout=60)
    try:
        value = float(out.strip())
        if value <= 0:
            raise ValueError()
        return value
    except Exception:
        raise RuntimeError(f"Could not read the duration of {path.name}.")


def shot_lengths(reference: Path) -> list[float]:
    """Return shot durations estimated from FFmpeg scene-change detections."""
    ref_duration = duration_of(reference)
    cmd = [
        "ffmpeg", "-hide_banner", "-i", str(reference),
        "-vf", "select='gt(scene,0.30)',showinfo",
        "-an", "-f", "null", "-"
    ]
    try:
        proc = subprocess.run(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, timeout=150, check=False
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError("Reference analysis took too long. Try a shorter reference clip.")

    detected = []
    for match in re.finditer(r"pts_time:([0-9]+(?:\.[0-9]+)?)", proc.stderr):
        stamp = float(match.group(1))
        if 0.25 < stamp < ref_duration - 0.25:
            if not detected or stamp - detected[-1] >= 0.45:
                detected.append(stamp)

    bounds = [0.0] + detected + [ref_duration]
    lengths = [b - a for a, b in zip(bounds, bounds[1:]) if b - a >= 0.35]

    # If the scene detector finds nothing, use a simple, regular editing rhythm.
    if len(lengths) <= 1 and ref_duration > 2.5:
        count = min(30, max(2, round(ref_duration / 2.5)))
        lengths = [ref_duration / count] * count
    if not lengths:
        lengths = [min(ref_duration, 2.5)]
    return lengths[:100]


def safe_extension(filename: str, allowed: set[str]) -> str:
    ext = Path(filename or "").suffix.lower()
    if ext not in allowed:
        raise HTTPException(400, f"Unsupported file type: {ext or 'missing extension'}.")
    return ext


async def save_upload(upload: UploadFile, directory: Path, allowed: set[str]) -> Path:
    ext = safe_extension(upload.filename or "", allowed)
    target = directory / (uuid.uuid4().hex + ext)
    total = 0
    try:
        with target.open("wb") as stream:
            while True:
                chunk = await upload.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_FILE_BYTES:
                    raise HTTPException(413, "Each file must be 100 MB or smaller.")
                stream.write(chunk)
    except Exception:
        target.unlink(missing_ok=True)
        raise
    finally:
        await upload.close()
    if total == 0:
        target.unlink(missing_ok=True)
        raise HTTPException(400, "One of the uploaded files was empty.")
    return target


def update_job(job_id: str, **changes):
    with jobs_lock:
        if job_id in jobs:
            jobs[job_id].update(changes)


def render_edit(job_id: str, folder: Path, references: list[Path],
                footage: list[Path], music: Optional[Path], aspect: str):
    work = folder / "work"
    work.mkdir(exist_ok=True)
    try:
        update_job(job_id, status="analysing", progress=15,
                   message="Analysing reference clips and detecting cut rhythm…")
        pattern = []
        for ref in references:
            pattern.extend(shot_lengths(ref))
        if not pattern:
            raise RuntimeError("No usable timing could be detected in the reference clips.")

        update_job(job_id, status="rendering", progress=30,
                   message="Preparing your footage and matching the shot lengths…")
        footage_durations = [duration_of(path) for path in footage]
        if sum(footage_durations) < 0.5:
            raise RuntimeError("Your footage appears to be too short or unreadable.")

        if aspect == "9:16":
            width, height = 720, 1280
        elif aspect == "1:1":
            width, height = 720, 720
        else:
            width, height = 1280, 720

        vf = (
            f"scale={width}:{height}:force_original_aspect_ratio=increase,"
            f"crop={width}:{height},setsar=1,fps=30,format=yuv420p"
        )

        segments = []
        source_index = 0
        source_offset = 0.0
        total = sum(footage_durations)
        source_used = 0.0

        for index, desired in enumerate(pattern):
            if source_used >= total - 0.2:
                break
            while source_index < len(footage) - 1 and source_offset >= footage_durations[source_index] - 0.15:
                source_index += 1
                source_offset = 0.0
            available = footage_durations[source_index] - source_offset
            if available <= 0.15:
                source_index += 1
                source_offset = 0.0
                if source_index >= len(footage):
                    break
                available = footage_durations[source_index]
            take = min(desired, available)
            if take < 0.25:
                continue

            segment = work / f"shot_{index:03d}.mp4"
            command([
                "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                "-ss", f"{source_offset:.3f}", "-i", str(footage[source_index]),
                "-t", f"{take:.3f}", "-an", "-vf", vf,
                "-c:v", "libx264", "-preset", "ultrafast", "-crf", "25",
                "-movflags", "+faststart", str(segment)
            ], timeout=240)
            segments.append(segment)
            source_offset += take
            source_used += take

        if not segments:
            raise RuntimeError("No video shots could be created. Try different source clips.")

        update_job(job_id, status="rendering", progress=75,
                   message="Joining the shots and finishing the MP4…")
        concat = work / "concat.txt"
        concat.write_text(
            "".join(f"file '{path.as_posix()}'\n" for path in segments),
            encoding="utf-8"
        )
        silent = work / "silent.mp4"
        command([
            "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
            "-f", "concat", "-safe", "0", "-i", str(concat),
            "-c", "copy", "-movflags", "+faststart", str(silent)
        ], timeout=240)

        output = folder / "clipmatch-finished.mp4"
        if music:
            command([
                "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                "-i", str(silent), "-stream_loop", "-1", "-i", str(music),
                "-map", "0:v:0", "-map", "1:a:0",
                "-c:v", "copy", "-c:a", "aac", "-b:a", "128k",
                "-shortest", "-movflags", "+faststart", str(output)
            ], timeout=240)
        else:
            shutil.copy2(silent, output)

        final_length = duration_of(output)
        update_job(job_id, status="completed", progress=100,
                   message="Your edited video is ready.",
                   download=f"/api/jobs/{job_id}/download",
                   shots=len(segments), duration=round(final_length, 1))
    except Exception as exc:
        update_job(job_id, status="failed", progress=100,
                   message=str(exc)[:1800])
    finally:
        shutil.rmtree(work, ignore_errors=True)


@app.get("/", response_class=HTMLResponse)
def home():
    return (STATIC / "index.html").read_text(encoding="utf-8")


@app.get("/health")
def health():
    return {"ok": True, "service": "ClipMatch AI"}


@app.post("/api/jobs")
async def create_job(
    background_tasks: BackgroundTasks,
    references: list[UploadFile] = File(...),
    footage: list[UploadFile] = File(...),
    music: Optional[UploadFile] = File(None),
    aspect: str = Form("9:16"),
):
    if not references or not footage:
        raise HTTPException(400, "Please add at least one reference and one footage clip.")
    if len(references) > MAX_REFERENCES:
        raise HTTPException(400, f"Upload no more than {MAX_REFERENCES} reference clips.")
    if len(footage) > MAX_FOOTAGE:
        raise HTTPException(400, f"Upload no more than {MAX_FOOTAGE} footage clips.")
    if aspect not in {"9:16", "16:9", "1:1"}:
        raise HTTPException(400, "Choose a valid video format.")

    job_id = uuid.uuid4().hex[:12]
    folder = DATA / job_id
    folder.mkdir(parents=True, exist_ok=False)
    try:
        reference_paths = [
            await save_upload(item, folder, ALLOWED_VIDEO) for item in references
        ]
        footage_paths = [
            await save_upload(item, folder, ALLOWED_VIDEO) for item in footage
        ]
        music_path = None
        if music and music.filename:
            music_path = await save_upload(music, folder, ALLOWED_AUDIO)
    except Exception:
        shutil.rmtree(folder, ignore_errors=True)
        raise

    with jobs_lock:
        jobs[job_id] = {
            "status": "queued", "progress": 5,
            "message": "Your files are uploaded. Your edit is queued.",
            "created": time.time()
        }

    background_tasks.add_task(
        render_edit, job_id, folder, reference_paths, footage_paths, music_path, aspect
    )
    return {"job_id": job_id, "status": "queued"}


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str):
    with jobs_lock:
        item = jobs.get(job_id)
        if not item:
            raise HTTPException(404, "This job is unavailable. The free server may have restarted.")
        return {"job_id": job_id, **item}


@app.get("/api/jobs/{job_id}/download")
def download_job(job_id: str):
    with jobs_lock:
        item = jobs.get(job_id)
        if not item:
            raise HTTPException(404, "This job is unavailable. Please create it again.")
        if item.get("status") != "completed":
            raise HTTPException(409, "The video is not ready yet.")
    output = DATA / job_id / "clipmatch-finished.mp4"
    if not output.is_file():
        raise HTTPException(404, "The finished video has expired after a server restart.")
    return FileResponse(
        output, media_type="video/mp4", filename="clipmatch-finished.mp4"
    )
