# ClipMatch AI — free-cloud prototype

ClipMatch AI is a cloud-hosted video-editing prototype. Upload reference clips, upload your footage, and it creates an MP4 edit using the approximate shot lengths detected in the references.

## What this prototype does

- Accepts up to 5 reference clips and 10 footage clips.
- Detects likely scene changes in the references with FFmpeg.
- Uses the reference shot lengths as a pacing guide.
- Cuts through the footage in the order you upload it.
- Crops the output to vertical (9:16), landscape (16:9), or square (1:1).
- Optionally adds an uploaded music track.
- Shows render progress and gives you an MP4 download.

## What it does not do yet

This is a first MVP, not a full generative AI editor. It imitates approximate cutting rhythm and shot duration. It does not yet understand the story in the clips, track people/objects, recreate complex motion graphics, copy exact transitions, or reproduce colour grades. More advanced AI analysis can be added after the first version is deployed and tested.

## Deploy to Render's free web service

Your computer is only used to create the GitHub repository and open the website. The server and FFmpeg do the editing online.

1. Create a GitHub account at https://github.com/ if you do not already have one.
2. Create a new repository. You can name it `clipmatch-ai`. For a public test project, choose **Public**.
3. Open the repository and choose **Add file → Upload files**.
4. Unzip this download on your computer. Upload the files and the `static` folder from the unzipped `clipmatch-ai` folder. Make sure `Dockerfile`, `app.py`, `render.yaml`, `requirements.txt`, `README.md`, and the `static` folder are at the top level of the repository.
5. Visit https://render.com/ and create an account.
6. In Render, choose **New → Web Service**, connect GitHub, and select the `clipmatch-ai` repository.
7. Render should detect the included `Dockerfile`. Select the **Free** instance type and deploy.
8. When the service has finished deploying, open its `onrender.com` URL. That is your ClipMatch AI website.

If Render does not detect Docker automatically, set the Runtime to **Docker** in the service settings. The included `render.yaml` also documents the service configuration.

## Free-tier limitations

Render's free web services have a 512 MB memory limit, may restart, sleep after 15 minutes without incoming traffic, and have an ephemeral filesystem. Files and jobs can disappear after a restart or sleep. The free tier is suitable for testing short, small videos, not dependable long-form rendering or permanent project storage. Keep clips short and small for the first tests, and download the result as soon as it is ready.

The server rejects files over 100 MB each. Hosting limits and performance can change; check the current Render free plan before relying on it.

## Privacy and safety

This demo has no user accounts or private project space. Anyone who can access the public website may be able to submit jobs. Do not upload private, sensitive, or confidential videos. Before sharing it publicly, add login, access controls, quotas, abuse protection, persistent object storage, and a proper job queue.

## Run locally for development

Install Python 3.11+ and FFmpeg, then run:

```bash
pip install -r requirements.txt
uvicorn app:app --host 127.0.0.1 --port 7860
```

Open http://127.0.0.1:7860. Local running is only for development; the hosted Render service performs the cloud rendering.
