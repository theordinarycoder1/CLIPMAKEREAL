const form = document.getElementById("editForm");
const refsInput = document.getElementById("references");
const footageInput = document.getElementById("footage");
const musicInput = document.getElementById("music");
const createBtn = document.getElementById("createBtn");
const progressPanel = document.getElementById("progressPanel");
const statusText = document.getElementById("statusText");
const progressBar = document.getElementById("progressBar");
const progressLabel = document.getElementById("progressLabel");
const result = document.getElementById("result");

function showFiles(input, target, emptyText) {
  const files = [...input.files];
  target.textContent = files.length ? files.map(f => `${f.name} (${(f.size / 1024 / 1024).toFixed(1)} MB)`).join(" · ") : emptyText;
}
refsInput.addEventListener("change", () => showFiles(refsInput, document.getElementById("referenceList"), "No reference videos selected"));
footageInput.addEventListener("change", () => showFiles(footageInput, document.getElementById("footageList"), "No footage selected"));
musicInput.addEventListener("change", () => document.getElementById("musicName").textContent = musicInput.files[0]?.name || "No music selected");

function setProgress(value) {
  const safe = Math.max(0, Math.min(100, Number(value) || 0));
  progressBar.style.width = `${safe}%`;
  progressLabel.textContent = `${safe}%`;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!refsInput.files.length || !footageInput.files.length) return;

  createBtn.disabled = true;
  createBtn.textContent = "Uploading clips…";
  progressPanel.hidden = false;
  statusText.textContent = "Uploading your clips to the cloud…";
  result.textContent = "Keep this page open while the upload finishes. The render runs on the online server.";
  setProgress(5);
  progressPanel.scrollIntoView({ behavior: "smooth", block: "center" });

  const data = new FormData();
  [...refsInput.files].forEach(file => data.append("references", file));
  [...footageInput.files].forEach(file => data.append("footage", file));
  if (musicInput.files[0]) data.append("music", musicInput.files[0]);
  data.append("aspect", document.getElementById("aspect").value);

  try {
    const response = await fetch("/api/jobs", { method: "POST", body: data });
    const body = await response.json();
    if (!response.ok) throw new Error(body.detail || "Upload failed.");
    statusText.textContent = "Your project is queued…";
    setProgress(10);
    pollJob(body.job_id);
  } catch (error) {
    showError(error.message);
  }
});

async function pollJob(jobId) {
  try {
    const response = await fetch(`/api/jobs/${encodeURIComponent(jobId)}`);
    const job = await response.json();
    if (!response.ok) throw new Error(job.detail || "Could not check render status.");

    statusText.textContent = job.message || "Working on your edit…";
    setProgress(job.progress);

    if (job.status === "completed") {
      result.innerHTML = `Ready · ${job.shots} shots · ${job.duration} seconds<br><a href="${job.download}">↓ Download your finished MP4</a>`;
      createBtn.disabled = false;
      createBtn.innerHTML = "<span>✦</span> Create another edit";
      return;
    }
    if (job.status === "failed") {
      showError(job.message || "The render failed.");
      return;
    }
    window.setTimeout(() => pollJob(jobId), 2500);
  } catch (error) {
    showError(error.message);
  }
}

function showError(message) {
  statusText.textContent = "Something went wrong";
  result.textContent = message;
  createBtn.disabled = false;
  createBtn.innerHTML = "<span>✦</span> Try again";
}
